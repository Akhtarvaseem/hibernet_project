//package com.jsp.hibernet_project_car_custmer.controller;
//
//import java.util.List;
//
//import com.jsp.hibernet_project_car_custmer.dto.Address;
//import com.jsp.hibernet_project_car_custmer.dto.Pan;
//import com.jsp.hibernet_project_car_custmer.dto.Persion;
//
//public class addressController {
//
//	public static void main(String[] args) {
//	
//	
//		
//	}
//
//}
