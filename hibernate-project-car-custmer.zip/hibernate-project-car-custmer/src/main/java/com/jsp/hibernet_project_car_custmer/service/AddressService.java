package com.jsp.hibernet_project_car_custmer.service;

import com.jsp.hibernet_project_car_custmer.dao.AddressDao;
import com.jsp.hibernet_project_car_custmer.dto.Address;

public class AddressService {
     
//	AddressDao dao=new AddressDao();
//	public void insertAddress(Address address) {
//		dao.insertAddress(address);
//	}
}
