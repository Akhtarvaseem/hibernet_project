//package com.jsp.hibernet_project_car_custmer.controller;
//
//import java.util.Scanner;
//
//import com.jsp.hibernet_project_car_custmer.dto.Address;
//import com.jsp.hibernet_project_car_custmer.dto.Pan;
//import com.jsp.hibernet_project_car_custmer.dto.Persion;
//import com.jsp.hibernet_project_car_custmer.service.PanService;
//
//public class PanController {
//
//	public static void main(String[] args) {
////		
////		Scanner sc= new Scanner(System.in);
////		Pan pan= new Pan();
////		Address address=new Address();
////		Persion persion=new Persion();
////		PanService service=new PanService();
////		
////		
////		System.out.println(" Enter pan id ");
////		pan.setId(sc.nextInt());
////		
////		System.out.println(" Enter pan panNumber ");
////		pan.setPanNum(sc.next());
////		
////		System.out.println(" Enter pan DOB ");
////		pan.setDOB(sc.next());
////		
////		System.out.println(" Enter pan Gender ");
////		pan.setGender(sc.next());
////
////		System.out.println(" Enter here Address ");
////		
////		System.out.println(" Enter Address id ");
////		address.setId(sc.nextInt());
////		
////		System.out.println(" Enter Address CityName ");
////		address.setCityName(sc.next());
////		
////		System.out.println(" Enter Address StreetName ");
////		address.setStreetName(sc.next());
////		
////		System.out.println(" Enter Address FlatNo ");
////		address.setFlatNo(sc.next());
////		
////		System.out.println(" Enter Address TwoName ");
////		address.setTownname(sc.next());
////		
////	    System.out.println(" Enter here persion details"); 
////		
////		System.out.println(" Enter persion id ");
////		persion.setId(sc.nextInt());
////		
////		System.out.println(" Enter persion name ");
////		persion.setName(sc.next());
////		
////		System.out.println(" Enter persion Phone number ");
////		persion.setPhone(sc.nextLong());
////
////		System.out.println(" Enter persion email ");
////		persion.setEmail(sc.next());
////
////		address.setPan(pan);
////		address.setPersion(persion);
////		pan.setAddress(address);
////		pan.setPersion(persion);
////		
////		service.insertPan(pan, address,persion);
//	}
//	
//
//}
