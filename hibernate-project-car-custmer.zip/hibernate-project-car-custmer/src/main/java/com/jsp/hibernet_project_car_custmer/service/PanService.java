package com.jsp.hibernet_project_car_custmer.service;

import com.jsp.hibernet_project_car_custmer.dao.PanDao;
import com.jsp.hibernet_project_car_custmer.dto.Address;
import com.jsp.hibernet_project_car_custmer.dto.Pan;
import com.jsp.hibernet_project_car_custmer.dto.Persion;

public class PanService {

//	PanDao dao=new PanDao();
//	public void insertPan(Pan pan, Address addredss,Persion persion) {
//	
//		dao.insertPan(pan, addredss, persion);
//	}
}
